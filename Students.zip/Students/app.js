const mongoose = require('mongoose'); 
const todoController = require('./controller/todocontroller');
const express = require('express');
const bodyParser= require('body-parser');
const app= express();
//mongodb+srv://startup:@cluster0-pnihr.mongodb.net/test?retryWrites=true&w=majority
mongoose.connect('mongodb+srv://rohit:rohit@rest-api-jtnqt.mongodb.net/test?retryWrites=true&w=majority',
{ useNewUrlParser: true,
  useUnifiedTopology: true 
});
mongoose.connection.on('error', function(error) {
  console.error('Database connection error:');
});
mongoose.connection.once('open', function() {
  console.log('Database connected');
});

app.set('view engine', 'ejs');
app.use(express.static('./public'));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use('/', todoController);
app.listen(3000,function(){console.log("Server is running in 3000")});