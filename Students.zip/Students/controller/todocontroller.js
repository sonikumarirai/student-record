const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const startup = require('../models/startup.js');
var data =[];


router.get('/', function(req, res){
    console.log("home request");
    startup.find()
    .select("name roll")
    .exec()
    .then(doc=>{
        console.log(doc);
            data=doc;
            res.render('index', {acc:data});
    })
    .catch(err => {
        console.log(err);
        res.status(500).json({error:err});
    });
 
});
router.get('/createnew', function(req, res){
    console.log("createnew request");
            res.render('createnew');
    })

router.post('/new', (req, res, next)=>{
    console.log("post request to /startup");
    const startup1 = new startup({
        _id: new mongoose.Types.ObjectId(),
        name: req.body.name,
        roll: req.body.roll
    }); 
    startup1.save().then(result =>{
        console.log(result);
        res.redirect("/");
    }).catch(err => {
        console.log(err);
        res.status(500).json({
            error: err
        })
    });
});

router.delete('/todo', function(req, res){

});
module.exports= router;